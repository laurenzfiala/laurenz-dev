#version 430 core

layout(points) in;
layout(triangle_strip, max_vertices = 4) out;

uniform mat4 projectionMatrix;

in VertexData {
	float ttl;
	vec4 color;
} vert[];

out vec2 texCoord0;
flat out float ttl0;
flat out vec4 color0;

void main()
{
    const vec2 size = vec2(0.1f, 0.1f);
    vec4 pos = gl_in[0].gl_Position;
    vec2 va;
    
    // bottom-left
    va = pos.xy + vec2(-0.5, -0.5) * size;
    gl_Position = projectionMatrix * vec4(va, pos.zw);
    texCoord0 = vec2(0, 0);
    ttl0 = vert[0].ttl;
    color0 = vert[0].color;
    EmitVertex();
    
    // bottom-right
    va = pos.xy + vec2(0.5, -0.5) * size;
    gl_Position = projectionMatrix * vec4(va, pos.zw);
    texCoord0 = vec2(1, 0);
    ttl0 = vert[0].ttl;
    EmitVertex();
    
    // top-left
    va = pos.xy + vec2(-0.5, 0.5) * size;
    gl_Position = projectionMatrix * vec4(va, pos.zw);
    texCoord0 = vec2(0, 1);
    ttl0 = vert[0].ttl;
    EmitVertex();
    
    // top-right
    va = pos.xy + vec2(0.5, 0.5) * size;
    gl_Position = projectionMatrix * vec4(va, pos.zw);
    texCoord0 = vec2(1, 1);
    ttl0 = vert[0].ttl;
    EmitVertex();
    
    EndPrimitive();
}