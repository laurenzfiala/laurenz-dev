#version 430 core

in vec2 texCoord0;
flat in vec4 color0;
flat in float ttl0;

uniform sampler2D diffuseTexture;

out vec4 FragColor;

void main()
{
    FragColor = vec4(color0.rgb, texture(diffuseTexture, texCoord0).a);
}