#version 430 core
out vec4 FragColor;

in vec2 textureCoords;

uniform sampler2D diffuseTexture;

void main()
{
    FragColor = texture(diffuseTexture, textureCoords);
}