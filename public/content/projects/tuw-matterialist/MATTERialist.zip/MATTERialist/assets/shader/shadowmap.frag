#version 430 core
/*
* Copyright 2019 Vienna University of Technology.
* Institute of Computer Graphics and Algorithms.
* This file is part of the ECG Lab Framework and must not be redistributed.
*
* Sources:
* http://www.opengl-tutorial.org/intermediate-tutorials/tutorial-16-shadow-mapping/ (15.4.2020)
* https://github.com/opengl-tutorials/ogl/blob/master/tutorial16_shadowmaps/ShadowMapping.fragmentshader (15.4.2020)
* https://learnopengl.com/Advanced-Lighting/Shadows/Shadow-Mapping (7.4.2020)
*/

// -------------------- CONSTANTS
const int 	MAX_POINT_LIGHTS 			= 10;
const int 	SHADOW_SAMPLES 				= 16;
const float SHADOW_SAMPLE_OFFSET_MULT 	= 0.0025;
const vec2 	SHADOW_POISSON[16] 			= vec2[]( 
   vec2( -0.94201624, -0.39906216 ), 
   vec2( 0.94558609, -0.76890725 ), 
   vec2( -0.094184101, -0.92938870 ), 
   vec2( 0.34495938, 0.29387760 ), 
   vec2( -0.91588581, 0.45771432 ), 
   vec2( -0.81544232, -0.87912464 ), 
   vec2( -0.38277543, 0.27676845 ), 
   vec2( 0.97484398, 0.75648379 ), 
   vec2( 0.44323325, -0.97511554 ), 
   vec2( 0.53742981, -0.47373420 ), 
   vec2( -0.26496911, -0.41893023 ), 
   vec2( 0.79197514, 0.19090188 ), 
   vec2( -0.24188840, 0.99706507 ), 
   vec2( -0.81409955, 0.91437590 ), 
   vec2( 0.19984126, 0.78641367 ), 
   vec2( 0.14383161, -0.14100790 ) 
);

// -------------------- STRUCTS
uniform struct DirectionalLight {
	vec3 color;
	vec3 direction;
} dirL;

uniform struct PointLight {
	vec3 color;
	vec3 position;
	vec3 attenuation;
	bool enabled;
} pointLights[MAX_POINT_LIGHTS];

// -------------------- ATTRIBUTES
in VertexData {
	vec3 position_world;
	vec3 normal_world;
	vec2 uv;
	vec4 dirLFragmentPosition;
} vert;
in mat3 TBN;

out vec4 color;


// -------------------- UNIFORMS
uniform vec3 camera_world;
uniform vec3 materialCoefficients; // x = ambient, y = diffuse, z = specular 
uniform float specularAlpha;
uniform sampler2D diffuseTexture;
uniform bool useSpecularTexture;
uniform sampler2D specularTexture;
uniform sampler2DShadow dirLDepthMap;
uniform sampler2D normalMap;
uniform bool useNormalMap;
uniform float brightnessMultiplier;

// -------------------- FUNCTIONS
vec3 phong(vec3 n, vec3 l, vec3 v, vec3 diffuseC, float diffuseF, vec3 specularC, float specularF, float alpha, bool attenuate, vec3 attenuation) {
	float d = length(l);
	l = normalize(l);
	float att = 1.0;	
	if(attenuate) att = 1.0f / (attenuation.x + d * attenuation.y + d * d * attenuation.z);
	vec3 r = reflect(-l, n);
	return (diffuseF * diffuseC * max(0, dot(n, l)) + specularF * specularC * pow(max(0, dot(r, v)), alpha)) * att; 
}

float shadow(sampler2DShadow sampler, vec4 fragPosLightSpace, vec3 lightDirection)
{
	vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
	projCoords = projCoords * 0.5 + 0.5;
	if(projCoords.z > 1.0) {
        return 0.0;
	}
	
	float bias = clamp(1.0 - dot(vert.normal_world, -lightDirection), 0.0, 0.001);
	float shadow = 0.0;
	float sampleWeight = (1.0 / SHADOW_SAMPLES);
	for (int i = 0; i < SHADOW_SAMPLES; ++i){
		shadow += sampleWeight * (1.0 - texture(sampler, vec3(projCoords.xy + SHADOW_POISSON[i] * SHADOW_SAMPLE_OFFSET_MULT, (projCoords.z - bias) / fragPosLightSpace.w)));
	}
	return shadow;
}

float shadowOnlyPCF(sampler2DShadow sampler, vec4 fragPosLightSpace, vec3 lightDirection)
{
	vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
	projCoords = projCoords * 0.5 + 0.5;
	if(projCoords.z > 1.0) {
        return 0.0;
	}
	
	float bias = clamp(1.0 - dot(vert.normal_world, -lightDirection), 0.0, 0.001);
	return 1.0 - texture(sampler, vec3(projCoords.xy, (projCoords.z - bias) / fragPosLightSpace.w));
}

void main() {

    //vec3 n = (2 * texture(normalMap, vert.uv).xyz) - 1.0f;
	//n = normalize(TBN * n);
	vec3 n = normalize(vert.normal_world);
	vec3 v = normalize(camera_world - vert.position_world);
	
	vec3 texColor = texture(diffuseTexture, vert.uv).rgb;
	float specularIntensity = texture(specularTexture, vert.uv).r;
	color = vec4(texColor * materialCoefficients.x, 1); // ambient
	
	float notShadow = 1.0 - shadow(dirLDepthMap, vert.dirLFragmentPosition, dirL.direction);
	
	// add directional light contribution
	color.rgb += notShadow * phong(n, -dirL.direction, v, dirL.color * texColor, materialCoefficients.y, dirL.color, materialCoefficients.z * specularIntensity, specularAlpha, false, vec3(0));
		
	for (int i = 0; i < MAX_POINT_LIGHTS; i++) {
		PointLight pointL = pointLights[i];
	
		if (!pointL.enabled) {
			continue;
		}
		// add point light contribution
		color.rgb += phong(n, pointL.position - vert.position_world, v, pointL.color * texColor, materialCoefficients.y, pointL.color, materialCoefficients.z * specularIntensity, specularAlpha, true, pointL.attenuation);
	}
    
    color.rgb *= brightnessMultiplier;
	
}

