#version 430 core
layout(location = 0) in vec3 position;
layout(location = 2) in vec2 uv;

out vec2 textureCoords;

uniform mat4 viewProjMatrix;
uniform mat4 modelMatrix;

void main()
{
    textureCoords = uv;
	gl_Position = viewProjMatrix * modelMatrix * vec4(position.xy, 0.0f, 1.0f);
}