#version 430 core

layout(location = 0) in vec4 position;
layout(location = 1) in vec4 color;

uniform mat4 modelViewMatrix;

out VertexData {
	float ttl;
	vec4 color;
} vert;

void main()
{
    gl_Position = modelViewMatrix * vec4(position.xyz, 1.0f);
    vert.ttl = position.w;
    vert.color = color;
}