#version 430 core
layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec2 uv;
layout(location = 3) in vec3 tangent;

const int MAX_POINT_LIGHTS = 11;

out VertexData {
	vec3 position_world;
	vec3 normal_world;
	vec2 uv;
	vec4 dirLFragmentPosition;
} vert;
out mat3 TBN;

uniform mat4 modelMatrix;
uniform mat4 viewProjMatrix;
uniform mat3 normalMatrix;
uniform mat4 dirLSpaceMatrix;

void main()
{
	vert.normal_world = normalMatrix * normal;
	vert.uv = uv;
	vec3 T = normalize(vec3(modelMatrix * vec4(tangent, 0.0f)));
	vec3 N = normalize(vec3(modelMatrix * vec4(normal, 0.0f)));
	vec3 B = normalize(cross(N, T));
	TBN = mat3(T, B, N);
	vec4 position_world_ = modelMatrix * vec4(position, 1);
    vert.position_world = position_world_.xyz;
	vert.dirLFragmentPosition = dirLSpaceMatrix * position_world_;
	gl_Position = viewProjMatrix * position_world_;
}